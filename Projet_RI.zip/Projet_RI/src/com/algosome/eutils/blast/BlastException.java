package com.algosome.eutils.blast;

/**
 * 
 * @author gregcope
 *
 */
public class BlastException extends Exception{

	static final long serialVersionUID = -3421341L;
	
	/**
	 * 
	 * @param message
	 */
	public BlastException(String message){
		super(message);
	}
}
